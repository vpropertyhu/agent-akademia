@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
 start "" "KEZDD-ITT.html"
 echo A futtatashoz Node.js 22 vagy ujabb verzio kell.
 pause
 exit /b 1
)
node server.mjs
pause
