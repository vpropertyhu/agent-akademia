#!/bin/sh
cd -- "$(dirname -- "$0")" || exit 1
if ! command -v node >/dev/null 2>&1; then
 open KEZDD-ITT.html
 echo "A futtatáshoz Node.js 22 vagy újabb verzió kell."
 exit 1
fi
node server.mjs
