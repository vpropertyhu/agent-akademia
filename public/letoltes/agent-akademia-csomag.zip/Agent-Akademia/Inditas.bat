@echo off
cd /d "%~dp0"
node start-menu.mjs
pause
